import { motion, useScroll, useTransform } from "framer-motion";
import { useRef } from "react";
import { ArrowRight, Mail, MapPin } from "lucide-react";

export default function Home() {
  const containerRef = useRef<HTMLDivElement>(null);
  const { scrollYProgress } = useScroll({
    target: containerRef,
    offset: ["start start", "end end"]
  });

  return (
    <div ref={containerRef} className="bg-white text-foreground min-h-screen selection:bg-black selection:text-white">
      {/* Navbar */}
      <nav className="fixed top-0 left-0 right-0 z-50 mix-blend-difference text-white p-6 md:p-12 flex justify-between items-start pointer-events-none">
        <div className="font-serif text-2xl tracking-tight">Eri.</div>
        <div className="flex flex-col items-end gap-2 text-sm font-medium tracking-wide">
          <a href="#work" className="pointer-events-auto hover:italic transition-all">Work</a>
          <a href="#about" className="pointer-events-auto hover:italic transition-all">About</a>
          <a href="#contact" className="pointer-events-auto hover:italic transition-all">Contact</a>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="relative h-[100dvh] flex flex-col md:flex-row w-full overflow-hidden">
        <div className="w-full md:w-1/2 h-full flex flex-col justify-end p-8 md:p-16 lg:p-24 z-10 bg-white md:bg-transparent mix-blend-normal pb-24 md:pb-16">
          <motion.div
            initial={{ opacity: 0, y: 50 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 1, ease: [0.16, 1, 0.3, 1], delay: 0.2 }}
          >
            <h1 className="font-serif text-5xl md:text-7xl lg:text-[7rem] leading-[0.9] tracking-tight text-black mb-6">
              Data Analyst.
              <br />
              <span className="italic text-muted-foreground">Strategist.</span>
            </h1>
            <p className="font-sans text-base md:text-lg max-w-md text-muted-foreground font-light leading-relaxed">
              I build revenue intelligence tools and investment dashboards that find what the data says, not what someone wants to hear.
            </p>
          </motion.div>
        </div>
        
        <div className="absolute md:relative inset-0 md:w-1/2 h-full z-0">
          <motion.div 
            className="w-full h-full bg-black"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 1.5 }}
          >
            <img 
              src="/analyst-portfolio/images/eri1.jpg" 
              alt="Eri - Data Analyst" 
              className="w-full h-full object-cover object-center opacity-90"
            />
          </motion.div>
        </div>
      </section>

      {/* Bio / Philosophy */}
      <section id="about" className="py-24 md:py-48 px-6 md:px-12 lg:px-24 bg-white">
        <div className="max-w-4xl mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 40 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: "-100px" }}
            transition={{ duration: 0.8, ease: "easeOut" }}
            className="space-y-12"
          >
            <h2 className="font-serif text-3xl md:text-5xl lg:text-6xl leading-tight">
              I'm a Statistics graduate from the University of Ibadan. I build revenue intelligence tools for B2B and e-commerce businesses whose customer data sits around half-used.
            </h2>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8 md:gap-16 text-muted-foreground font-sans font-light text-lg leading-relaxed">
              <p>
                Not spending years inside one industry has worked in my favour. I don't carry its assumptions, and my training is genuinely quantitative. I run numbers to find out what they say, not to confirm a hypothesis someone already loves.
              </p>
              <p>
                Most of the dashboards I build do two things: show what happened, and say what to do about it. The second part is usually why someone hired me.
              </p>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Break Image 1 */}
      <section className="h-[70vh] md:h-[90vh] w-full overflow-hidden">
        <motion.div 
          className="w-full h-full"
          style={{ 
            scale: useTransform(scrollYProgress, [0.2, 0.4], [1.1, 1])
          }}
        >
          <img 
            src="/analyst-portfolio/images/eri2.jpg" 
            alt="Eri - Relaxed" 
            className="w-full h-full object-cover object-top"
          />
        </motion.div>
      </section>

      {/* Selected Work */}
      <section id="work" className="py-24 md:py-48 px-6 md:px-12 lg:px-24 bg-black text-white">
        <div className="max-w-7xl mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="mb-20 md:mb-32 flex flex-col md:flex-row md:items-end justify-between gap-8"
          >
            <h2 className="font-serif text-5xl md:text-7xl">Selected<br/><span className="italic text-gray-400">Work</span></h2>
            <p className="font-sans font-light text-gray-400 max-w-sm">
              Tools built to answer difficult questions and surface hidden revenue.
            </p>
          </motion.div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-x-8 gap-y-24 md:gap-y-32">
            {[
              {
                title: "B2B Revenue Intelligence",
                category: "SaaS Dashboard",
                desc: "A custom tool that identifies churn risks 60 days before renewal and models pricing elasticity for upselling mid-market accounts."
              },
              {
                title: "Macro Regime Tracker",
                category: "Investor Tool",
                desc: "Tracking where we are in the economic cycle, identifying sector rotation opportunities, and stress-testing theses against past regimes."
              },
              {
                title: "E-Commerce Cohort Analysis",
                category: "Retention Model",
                desc: "Segmenting customer lifetime value by acquisition channel to reallocate marketing spend towards high-LTV cohorts."
              },
              {
                title: "Supply Chain Stress Tester",
                category: "Logistics Dashboard",
                desc: "Simulating margin impacts across 14 different fulfillment scenarios to optimize inventory distribution across regional hubs."
              }
            ].map((project, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, y: 50 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, margin: "-50px" }}
                transition={{ duration: 0.7, delay: i % 2 === 0 ? 0 : 0.2 }}
                className={`group cursor-pointer ${i % 2 !== 0 ? 'md:mt-32' : ''}`}
              >
                <div className="aspect-[4/3] bg-gray-900 mb-8 overflow-hidden relative">
                  {/* Abstract placeholder for project visual */}
                  <div className="absolute inset-0 opacity-20 flex items-center justify-center">
                     <div className="w-full h-[1px] bg-white absolute top-1/3 transform -rotate-12 transition-transform group-hover:rotate-0 duration-700"></div>
                     <div className="w-full h-[1px] bg-white absolute bottom-1/3 transform rotate-12 transition-transform group-hover:rotate-0 duration-700"></div>
                     <div className="w-[1px] h-full bg-white absolute left-1/3 transform rotate-12 transition-transform group-hover:rotate-0 duration-700"></div>
                  </div>
                  <div className="absolute inset-0 flex items-center justify-center">
                    <span className="font-serif text-3xl italic text-gray-700 group-hover:text-white transition-colors duration-500">{project.category}</span>
                  </div>
                </div>
                <div className="space-y-4">
                  <h3 className="font-serif text-3xl border-b border-gray-800 pb-6 group-hover:border-white transition-colors duration-500 flex justify-between items-center">
                    {project.title}
                    <ArrowRight className="opacity-0 -translate-x-4 group-hover:opacity-100 group-hover:translate-x-0 transition-all duration-500" />
                  </h3>
                  <p className="font-sans font-light text-gray-400 leading-relaxed max-w-md">
                    {project.desc}
                  </p>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Investor Section */}
      <section className="py-24 md:py-48 px-6 md:px-12 lg:px-24 bg-white">
        <div className="max-w-4xl mx-auto text-center space-y-12">
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true }}
            transition={{ duration: 1 }}
          >
            <h2 className="font-serif text-4xl md:text-5xl lg:text-7xl leading-tight">
              I also build tools <span className="italic text-muted-foreground">for investors.</span>
            </h2>
            <p className="mt-12 text-lg md:text-xl font-sans font-light text-muted-foreground max-w-2xl mx-auto leading-relaxed">
              Dashboards that track where we are in the economic cycle, identify which sectors look worth overweighting, and stress-test the thesis against past regimes before anyone commits money.
            </p>
          </motion.div>
        </div>
      </section>

      {/* Break Image 2 */}
      <section className="h-[60vh] md:h-[80vh] w-full overflow-hidden">
        <motion.div 
          className="w-full h-full"
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          transition={{ duration: 1 }}
        >
          <img 
            src="/analyst-portfolio/images/eri3.jpg" 
            alt="Eri - Close up" 
            className="w-full h-full object-cover object-center"
          />
        </motion.div>
      </section>

      {/* Skills / Approach */}
      <section className="py-24 md:py-48 px-6 md:px-12 lg:px-24 bg-white border-b border-gray-100">
        <div className="max-w-7xl mx-auto grid grid-cols-1 md:grid-cols-12 gap-12 md:gap-24">
          <div className="md:col-span-5">
            <h2 className="font-serif text-4xl md:text-5xl sticky top-32">
              Capabilities<br/><span className="italic text-muted-foreground">& Stack.</span>
            </h2>
          </div>
          <div className="md:col-span-7 space-y-16">
            {[
              {
                title: "Data Modeling & Architecture",
                desc: "Structuring messy, disparate data sources into clean, reliable single sources of truth. R, Python, SQL, dbt."
              },
              {
                title: "Revenue Intelligence",
                desc: "Building predictive models for churn, LTV, and pricing elasticity. Moving beyond historical reporting to forward-looking strategy."
              },
              {
                title: "Dashboard Engineering",
                desc: "Creating bespoke, highly interactive interfaces that tell a story. Not just charts on a page, but interactive tools that drive decisions."
              },
              {
                title: "Statistical Rigor",
                desc: "Applying academic statistical methods to business problems. A/B testing, cohort analysis, regression modeling without the assumptions."
              }
            ].map((skill, i) => (
              <motion.div 
                key={i}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, delay: i * 0.1 }}
                className="space-y-4"
              >
                <h3 className="font-serif text-2xl border-b border-gray-200 pb-4">{skill.title}</h3>
                <p className="font-sans font-light text-muted-foreground leading-relaxed">
                  {skill.desc}
                </p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Contact / Footer */}
      <section id="contact" className="py-24 md:py-32 px-6 md:px-12 lg:px-24 bg-black text-white relative overflow-hidden">
        <div className="max-w-7xl mx-auto relative z-10">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-16 md:gap-24">
            <div>
              <h2 className="font-serif text-5xl md:text-7xl lg:text-[8rem] leading-[0.9] tracking-tight mb-8">
                Let's<br/>
                <span className="italic text-gray-500">talk.</span>
              </h2>
              <p className="font-sans font-light text-gray-400 text-lg max-w-sm mb-12">
                Currently taking on new projects. If you have data that sits around half-used, we should speak.
              </p>
              <a href="mailto:hello@example.com" className="inline-flex items-center gap-4 text-xl font-serif hover:italic transition-all group border-b border-white/20 pb-2">
                <Mail className="w-5 h-5 text-gray-400 group-hover:text-white transition-colors" />
                Get in touch
              </a>
            </div>
            
            <div className="flex flex-col justify-end space-y-8 text-gray-400 font-sans font-light">
              <div className="space-y-2">
                <p className="text-white font-medium uppercase tracking-widest text-xs">Location</p>
                <p className="flex items-center gap-2">
                  <MapPin className="w-4 h-4" />
                  Ibadan, Nigeria / Global
                </p>
              </div>
              <div className="space-y-2">
                <p className="text-white font-medium uppercase tracking-widest text-xs">Socials</p>
                <div className="flex gap-6">
                  <a href="#" className="hover:text-white transition-colors">LinkedIn</a>
                  <a href="#" className="hover:text-white transition-colors">Twitter</a>
                  <a href="#" className="hover:text-white transition-colors">GitHub</a>
                </div>
              </div>
            </div>
          </div>
          
          <div className="mt-32 pt-8 border-t border-white/10 flex flex-col md:flex-row justify-between items-center gap-4 text-sm text-gray-600 font-light">
            <p>© {new Date().getFullYear()} Eri.</p>
            <p>Data Analyst & Strategist.</p>
          </div>
        </div>
      </section>
    </div>
  );
}